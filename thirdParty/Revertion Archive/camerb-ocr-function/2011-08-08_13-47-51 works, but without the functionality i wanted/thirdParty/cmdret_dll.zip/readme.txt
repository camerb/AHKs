CMDret - v3.2.1 (DLL version) 

Beta version - NO WARRANTIES OF ANY KIND. USE AT YOUR OWN RISK. 

CMDret v3.x is a .DLL file (Freeware) that has been designed to return the output from a console program to a variable (rather than redirect to a textbox like the command line version). Version 3.1 (or greater) now includes a function that has the ability to output to a control and should be more stable than the command line version. Please keep in mind that CMDret is currently a beta realease. Any feedback would be greatly appreciated. 

Updated: March 15, 2008 - version 3.2.1 

Current functions: 

RunReturn(CMD, StrOut) 
- CMD - the console program/command to execute (str) 
- StrOut - the variable used to store the output (str) 
= If the function fails, the return value is zero 

RunWEx(CMD, CMDdir, CMDin, CMDout, CMDerr) 
- CMD - the console program/command to execute (str) 
- CMDdir - Future Use (working directory - not currently functional) (str) 
- CMDin - StdInput String (str) 
- CMDout - the variable used to store StdOutput output (str) 
- CMDerr - the variable used to store StdError output (str) 
= If the function fails, the return value is zero 

RunRedirect(CMD) 
- Where CMD is the console program/command to execute (str) 

RunInControl(CMD, CtrlHWND) 
- CMD should be the console program/command to execute (str) 
- CtrlHWND should be the handle to the control to stream into
= If the function fails, the return value is zero 


Note: only 32 bit console applications will currently work with the this dll version of CMDret (v3.2.1 or lower). Calls that require command.com will likely not produce any output and may crash. To avoid this I have included a file named "cmdstub.exe" with the download (in the Win9x folder). This file should be used when calling 16 bit console applications to enable returning output. Example: cmdstub.exe command.com /C set